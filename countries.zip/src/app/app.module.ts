import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppComponent } from "./app.component";
import { StoreModule } from "@ngrx/store";
import { appReducers } from "./store/reducers/app.reducers";
import { EffectsModule } from "@ngrx/effects";
import { AppEffects } from "./store/effects/app.effects";
import { HttpModule } from "@angular/http";
import { AppService } from "./services/app.service";
import { CountryInfo } from "./components/countryinfo/countryinfo.component";
import { DropdownComponent } from "./components/dropdown/dropdown.component";
import { SsComponent } from './ss/ss.component';

@NgModule({
  declarations: [AppComponent, CountryInfo, DropdownComponent, SsComponent],
  imports: [
    BrowserModule,
    StoreModule.forRoot({ app: appReducers }),
    EffectsModule.forRoot([AppEffects]),
    HttpModule
  ],

  providers: [AppService],
  bootstrap: [AppComponent]
})
export class AppModule {}
