export interface Region {
  name: string;
}
