import { createSelector } from "@ngrx/store";
import { AppActions } from "../actions/app.actions";
import { AppState, MainAppState } from "./../state/app.state";
import { Country } from "./../../models/country";

const appSelect = (state: MainAppState) => state.app;

export const selectRegions = createSelector(
  appSelect,
  (state: AppState) => state.regions
);

export const selectCountries = createSelector(
  appSelect,
  (state: AppState) => state.countries
);

export const selectCountryInfo = createSelector(
  appSelect,
  (state: AppState) => state.countryInfo
);
