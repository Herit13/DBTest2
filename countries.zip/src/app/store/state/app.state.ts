import { Country } from "./../../models/country";
import { Region } from "./../../models/region";

export interface AppState {
  region: Region;
  regions: Region[];
  country: string;
  countries: Country[];
  countryInfo: Country;
}
export interface MainAppState {
  app: AppState;
}

export const initialAppState: AppState = {
  region: null,
  regions: [{ name: "Europe" }, { name: "Asia" }],
  country: null,
  countries: [],
  countryInfo: null
};

export const initialAppMainState: MainAppState = {
  app: initialAppState
};

export function getInitialMainState(): MainAppState {
  return initialAppMainState;
}

export function getInitialState(): AppState {
  return initialAppState;
}
