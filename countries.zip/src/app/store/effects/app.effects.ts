import { Injectable } from "@angular/core";

import { Store, select } from "@ngrx/store";

import { AppService } from "./../../services/app.service";
import { MainAppState } from "../state/app.state";
import {
  GetCountries,
  GetCountriesSuccess,
  GetCountry,
  GetCountrySuccess,
  EAppActions
} from "../actions/app.actions";
//import { selectCountryList } from "./../selectors/app.selectors";
import { of } from "rxjs";
import { Country } from "./../../models/country";

import { Actions, createEffect, ofType, Effect } from "@ngrx/effects";
import { EMPTY } from "rxjs";
import {
  map,
  mergeMap,
  catchError,
  switchMap,
  withLatestFrom
} from "rxjs/operators";

@Injectable({
  providedIn: "root"
})
export class AppEffects {
  @Effect()
  getCountries$ = this._actions.pipe(
    ofType<GetCountries>(EAppActions.GetCountries),
    switchMap(region => this._appService.getCountries(region.payload)),
    switchMap(countries => {
      return of(new GetCountriesSuccess(countries.json()));
    })
  );

  @Effect()
  getCountry$ = this._actions.pipe(
    ofType<GetCountry>(EAppActions.GetCountry),
    switchMap(action => this._appService.getCountry(action.payload)),
    switchMap(country => {
      console.log(country);
      return of(new GetCountrySuccess(country.json()));
    })
  );

  constructor(
    private _appService: AppService,
    private _actions: Actions,
    private _store: Store<MainAppState>
  ) {}
}
