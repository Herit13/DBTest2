import { Component, Input, Output, EventEmitter } from "@angular/core";

@Component({
  selector: "app-dropdown",
  templateUrl: "./dropdown.component.html",
  styleUrls: ["./dropdown.component.css"]
})
export class DropdownComponent {
  @Input() data: Object[];
  @Input() label: String;
  @Output() changed = new EventEmitter<boolean>();

  onChange(value) {
    this.changed.emit(value);
  }
}
