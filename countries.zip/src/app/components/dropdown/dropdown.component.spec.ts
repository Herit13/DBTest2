import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { DropdownComponent } from "./dropdown.component";

describe("DropdownComponent", () => {
  let component: DropdownComponent;
  let fixture: ComponentFixture<DropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DropdownComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DropdownComponent);
    component = fixture.componentInstance;
    component.label = "test input";
    component.data = [
      { name: "test", alpha3Code: "testcode" },
      { name: "test1", alpha3Code: "testcode1" }
    ];
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should emit on select", done => {
    component.changed.subscribe(value => {
      expect(value).toEqual("testcode1");
      done();
    });

    const select = fixture.debugElement.query(By.css(`select`)).nativeElement;
    select.value = select.options[1].value;
    select.dispatchEvent(new Event("change"));
    fixture.detectChanges();
  });

  it("should show label", () => {
    expect(fixture.nativeElement.querySelector("label").innerText).toEqual(
      "test input"
    );
  });
});
