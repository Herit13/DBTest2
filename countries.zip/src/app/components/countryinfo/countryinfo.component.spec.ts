import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { CountryInfo } from "./countryinfo.component";

describe("CountryInfoComponent", () => {
  let component: CountryInfo;
  let fixture: ComponentFixture<CountryInfo>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CountryInfo]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CountryInfo);
    component = fixture.componentInstance;
    var country = {
      name: "TestCountry",
      capital: "TestCapital",
      population: 100,
      currencies: [{ code: "TST", name: "TEST", symbol: "T" }],
      flag: "flag.jpg"
    };

    component.country = country;

    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should display name", () => {
    expect(
      fixture.nativeElement.innerText.indexOf("TestCountry") != -1
    ).toBeTrue();
  });

  it("should display capital", () => {
    expect(
      fixture.nativeElement.innerText.indexOf("TestCapital") != -1
    ).toBeTrue();
  });

  it("should display population", () => {
    expect(
      fixture.nativeElement.innerText.indexOf("Population") != -1
    ).toBeTrue();
  });

  it("should display currency", () => {
    expect(fixture.nativeElement.innerText.indexOf("TST") != -1).toBeTrue();
    expect(fixture.nativeElement.innerText.indexOf("TEST") != -1).toBeTrue();
  });

  it("should display image", () => {
    const image = fixture.nativeElement.querySelector("img");
    console.log(image.src);
    expect(image.src.indexOf("flag.jpg") != -1).toBeTrue();
  });
});
