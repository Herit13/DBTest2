export interface Currency {
  code: string;
  name: string;
  symbol: string;
}
