import { Country } from "./country";
export interface Region {
  name: string;
  countries: Country[];
}
