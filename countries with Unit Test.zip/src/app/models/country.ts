import { Currency } from "./currency";

export interface Country {
  alpha3Code: string;
  name: string;
  capital: string;
  population: number;
  currencies: Currency[];
  flag: string;
  region: string;
}
