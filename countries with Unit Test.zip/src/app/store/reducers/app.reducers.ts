import { initialAppState } from "../state/app.state";
import { EAppActions, AppActions } from "../actions/app.actions";
import { AppState } from "./../state/app.state";

export const appReducers = (
  state = initialAppState,
  action: AppActions
): AppState => {
  switch (action.type) {
    case EAppActions.GetCountriesSuccess: {
      // cache countries to each region
      state.regions.forEach(function(item) {
        if (item.name == action.payload[0].region) {
          item.countries = action.payload;
        }
      });
      return {
        ...state,
        countries: action.payload
      };
    }
    case EAppActions.GetCountry: {
      console.log(state.countries);
      let country;
      state.countries.forEach(function(item) {
        if (item.alpha3Code == action.payload) {
          country = item;
        }
      });
      console.log(country);
      return {
        ...state,
        country: action.payload,
        countryInfo: country
      };
    }

    default: {
      return state;
    }
  }
};
