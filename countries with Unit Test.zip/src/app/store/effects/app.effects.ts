import { Injectable } from "@angular/core";

import { Store, select } from "@ngrx/store";

import { AppService } from "./../../services/app.service";
import { MainAppState } from "../state/app.state";
import {
  GetCountries,
  GetCountriesSuccess,
  GetCountry,
  EAppActions
} from "../actions/app.actions";

import { of } from "rxjs";
import { Actions, ofType, Effect } from "@ngrx/effects";
import { switchMap, withLatestFrom } from "rxjs/operators";
import { selectRegions } from "./../selectors/app.selectors";

@Injectable({
  providedIn: "root"
})
export class AppEffects {
  @Effect()
  getCountries$ = this._actions.pipe(
    ofType<GetCountries>(EAppActions.GetCountries),
    withLatestFrom(this._store.select(selectRegions), (action, regions) => {
      return { action, regions };
    }),
    switchMap(obj => {
      const { action, regions } = obj;
      let countryRegions;
      regions.forEach(item => {
        if (item.name == action.payload) {
          if (item.countries.length > 0) {
            countryRegions = item.countries;
          }
        }
      });
      if (countryRegions) {
        return of(countryRegions);
      }
      return this._appService.getCountries(action.payload);
    }),
    switchMap(countries => {
      if (countries instanceof Array) {
        return of(new GetCountriesSuccess(countries));
      }
      return of(new GetCountriesSuccess(countries.json()));
    })
  );

  constructor(
    private _appService: AppService,
    private _actions: Actions,
    private _store: Store<MainAppState>
  ) {}
}
